#### Preamble ####
# Purpose: Cleans and filters raw data related to food insecurity in Toronto to ensure accuracy and uniformity for further analysis.
# Author: Uma Sadhwani
# Date: 24 September 2024
# Contact: uma.sadhwani@mail.utoronto.ca
# License: MIT 
# Pre-requisites: tidyverse and janitor packages installed. This script assumes the raw data includes measurements of household incomes and expenses that may require formatting corrections and error checks.
# Any other information needed? This script is part of a larger project analyzing food insecurity, as of 2023, in Toronto.
library(tidyverse)
library(janitor)
library(dplyr)

# Load data and clean column names
raw_data <- read_csv("cost of living toronto/starter_folder/data/raw_data/raw_data.csv")
cleaned_data <- raw_data %>% clean_names()

# Check column names after cleaning
print("Column names after cleaning:")
print(colnames(cleaned_data))

# Define selected scenarios with correct names
selected_scenarios <- c(
  "scenario_2_family_of_four_full_time_minimum_wage_earner",
  "scenario_3_family_of_four_median_income",
  "scenario_4_single_parent_household_with_2_children_ontario_works",
  "scenario_5_one_person_household_ontario_works"
)

# Pivot and filter the data
filtered_data <- cleaned_data %>%
  pivot_longer(
    cols = selected_scenarios,
    names_to = "scenario",
    values_to = "values"
  ) %>%
  filter(scenario %in% selected_scenarios)

# Save the filtered data
write_csv(filtered_data, "cost of living toronto/starter_folder/data/analysis_data/analysis_data.csv")
print("Filtered data download and save complete.")