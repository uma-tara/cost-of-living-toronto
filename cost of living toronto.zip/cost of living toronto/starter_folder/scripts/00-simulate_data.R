#### Preamble ####
# Purpose: Simulates household income and expenses data for various scenarios related to food insecurity.
# Author: Uma Sadhwani
# Date: 24 September 2024
# Contact: uma.sadhwani@mail.utoronto.ca
# License: MIT
# Pre-requisites: Knowledge of income and expense categories for different household scenarios related to food insecurity.
# Any other information needed? This is the first step in a series of scripts that will analyze the impact of household characteristics on food insecurity.

# Load necessary libraries
library(dplyr)

# Set seed for reproducibility
set.seed(123)

# Define a function to simulate monetary values within a range
simulate_money <- function(n, min, max) {
  as.character(paste0("$", format(round(runif(n, min, max), 2), big.mark = ",")))
}

# Define scenarios and categories
scenarios <- c("Family of Four, Ontario Works",
               "Family of Four, Full-Time Minimum Wage Earner",
               "Family of Four, Median Income",
               "Single Parent Household with 2 Children, Ontario Works",
               "One person Household, Ontario Works",
               "One Person Household, Old Age Security",
               "Married Couple, Ontario Disability Support Program")

categories <- c("Income from Employment", "Basic Allowance", "Maximum Shelter Allowance",
                "Old Age Security/Guaranteed Income Supplement", "Ontario Guaranteed Annual Income System", "Canada Child Benefit", "GST/HST credit", "Ontario Trillium Benefit", "Canada Worker Benefit", "Employment Insurance paid", "Canada Pension Plan paid", "Climate Action Incentive Payment (CAIP)", "Pregnancy/Breast-feeding Nutritional Allowance (non-lactose intolerant)", "Total", "Average Monthly Rent", "Food", "Childcare", "Transportation", "Total", "Funds Remaining", "Percentage of income required for rent", "Percentage of income required to purchase healthy food")

# Simulate data for each scenario
data_list <- lapply(scenarios, function(scenario) {
  data.frame(
    Category = rep("Income", length(categories)),
    Item = categories,
    Amount = sapply(categories, function(x) simulate_money(1, 300, 9500)),
    Scenario = rep(scenario, length(categories))
  )
})

# Combine all scenarios into one dataframe
simulated_data <- bind_rows(data_list)

# Add variability by inserting NA values randomly
simulated_data$Amount <- ifelse(runif(nrow(simulated_data)) > 0.8, NA, simulated_data$Amount)

# Output the simulated dataset
write.csv(simulated_data, "simulated_income_data.csv", row.names = FALSE)

print("Data simulation complete and file has been saved.")
