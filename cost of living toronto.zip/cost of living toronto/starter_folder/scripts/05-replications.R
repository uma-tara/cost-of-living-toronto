#### Preamble ####
# Purpose: Replicate graphs from a seminal paper on the effects of urban development on local economies, specifically focusing on income levels and rent prices across different city districts.
# Author: Uma Sadhwani
# Date: 24 September 2024
# Contact: uma.sadhwani@mail.utoronto.ca
# License: MIT
# Pre-requisites: R with tidyverse for data manipulation and ggplot2 for graphing. Ensure all data files are pre-cleaned and formatted in CSV.
# Any other information needed? This script is part of a research project funded by the City of Toronto to evaluate the accuracy of historical data models in predicting current economic conditions.

#### Workspace setup ####
library(tidyverse)  # Loads ggplot2, dplyr, tidyr, readr, purrr, tibble, stringr, forcats
# Check for necessary package installation
if (!requireNamespace("ggplot2", quietly = TRUE)) {
  install.packages("ggplot2")
}
if (!requireNamespace("dplyr", quietly = TRUE)) {
  install.packages("dplyr")
}

#### Load data ####
# Load the dataset containing information about income levels and rent prices by district
data_path <- "cost of living toronto/starter_folder/data/analysis_data/analysis_data.csv"
urban_data <- read_csv(data_path)

# Verify the data loaded correctly by looking at the first few rows
print(head(urban_data))

#### Data Analysis and Graph Replication ####
# Graph 1: Income Levels by District
income_plot <- ggplot(urban_data, aes(x = district, y = income)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  theme_minimal() +
  labs(title = "Income Levels by District",
       x = "District",
       y = "Average Income",
       caption = "Data source: City of Toronto")

# Save the first graph
ggsave("graphs/income_levels_by_district.png", plot = income_plot, width = 10, height = 8)

# Graph 2: Rent Prices by District
rent_plot <- ggplot(urban_data, aes(x = district, y = rent)) +
  geom_line(group = 1, colour = "red") +
  geom_point(colour = "red") +
  theme_minimal() +
  labs(title = "Rent Prices by District",
       x = "District",
       y = "Average Rent",
       caption = "Data source: City of Toronto")

# Save the second graph
ggsave("cost of living toronto/starter_folder/other/rent_prices_by_district.png", plot = rent_plot, width = 10, height = 8)

#### Conclusion ####
print("Graphs replicated successfully and saved to the 'graphs' directory.")

