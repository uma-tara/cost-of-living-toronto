#### Preamble ####
# Purpose: onduct statistical tests on the dataset concerning food insecurity in Toronto to analyze trends and provide insights into household impacts.
# Author: Uma Sadhwani
# Date: 24 September 2024
# Contact: uma.sadhwani@mail.utoronto.ca 
# License: MIT
# Pre-requisites: The script requires the tidyverse package for data manipulation and ggplot2 for data visualization. Ensure all datasets are pre-loaded and cleaned as required.
# Any other information needed? This script is part of a larger project funded by the University of Toronto to study the dynamics of food security and its socio-economic impacts across various Toronto neighborhoods.


#### Workspace setup ####
library(tidyverse)  # Loads ggplot2, dplyr, tidyr, readr, purrr, tibble, stringr, forcats
library(ggplot2)    # Specifically load ggplot2 for visualization purposes

# Verify the installation of required packages
if (!requireNamespace("tidyverse", quietly = TRUE)) {
  install.packages("tidyverse")
}

if (!requireNamespace("ggplot2", quietly = TRUE)) {
  install.packages("ggplot2")
}

# Load the data
raw_data_path <- "cost of living toronto/starter_folder/data/raw_data/raw_data.csv"
raw_data <- read_csv(raw_data_path)

# Clean and prepare data for testing
cleaned_data <- raw_data %>%
  clean_names() %>%
  drop_na()  # Drop missing values for accurate testing

# Print a snippet of the cleaned data to verify
print(head(cleaned_data))

#### Data Analysis and Visualization ####
# Assuming a simple analysis to start - modify as necessary for your tests
summary_stats <- cleaned_data %>%
  summarise(
    average_income = mean(income, na.rm = TRUE),
    median_rent = median(rent, na.rm = TRUE),
    max_expenses = max(expenses, na.rm = TRUE)
  )

# Display summary statistics
print(summary_stats)

# Simple visualization
ggplot(cleaned_data, aes(x = income, y = rent)) +
  geom_point() +
  labs(title = "Income vs. Rent in Toronto",
       x = "Income ($)",
       y = "Rent ($)")

# Save processed data and plots as required
write_csv(cleaned_data, "cost of living toronto/starter_folder/data/analysis_data/analysis_data.csv")
ggsave("cost of living toronto/starter_folder/other")

#### Conclusion ####
# Print a completion message
print("Data analysis and visualization complete.")

