#### Preamble ####
# Purpose: Models the relationship between aircraft flying time and its physical dimensions (length and width) to understand factors affecting aerodynamic performance.
# Author: Uma Sadhwani
# Date: 24 September 2024
# Contact: uma.sadhwani@mail.utoronto.ca
# License: MIT
# Pre-requisites: R packages tidyverse for data manipulation and rstanarm for Bayesian statistical modeling are required.
# Any other information needed? This script forms part of an ongoing research initiative examining the influence of design parameters on aircraft efficiency, supported by the University of Toronto's Department of Aerospace Studies.

#### Workspace setup ####
library(tidyverse)  # For data manipulation
library(rstanarm)  # For Bayesian modeling

#### Read data ####
# Ensure the data path is correct and the data file is properly formatted
analysis_data <- read_csv("cost of living toronto/starter_folder/data/analysis_data/analysis_data.csv")

### Model data ####
# Build a Bayesian regression model to assess how wing dimensions impact flying time
first_model <- stan_glm(
  formula = flying_time ~ length + width,  # Define the model formula
  data = analysis_data,  # Specify the dataset
  family = gaussian(),  # Assume a normal distribution for the response
  prior = normal(location = 0, scale = 2.5, autoscale = TRUE),  # Normal priors for coefficients
  prior_intercept = normal(location = 0, scale = 2.5, autoscale = TRUE),  # Normal prior for the intercept
  prior_aux = exponential(rate = 1, autoscale = TRUE),  # Exponential prior for the dispersion parameter
  seed = 853  # Set a seed for reproducibility
)

#### Save model ####
# Save the model to disk for future analysis
saveRDS(
  first_model,
  file = "models/first_model.rds"
)

#### Output model summary ####
# Print a summary of the model to get an overview of the fit and coefficients
print(summary(first_model))

# Optional: Visualize the effects of length and width on flying time
plot_effect <- ggplot(analysis_data, aes(x = length, y = flying_time, color = width)) +
  geom_point(alpha = 0.5) +
  geom_smooth(method = "lm", formula = y ~ poly(x, 2), se = FALSE) +
  labs(title = "Effect of Wing Length and Width on Flying Time",
       x = "Wing Length (mm)",
       y = "Flying Time (sec)",
       color = "Wing Width (mm)") +
  theme_minimal()

# Save the plot
ggsave("models/flying_time_effects_plot.png", plot = plot_effect, width = 10, height = 8)
